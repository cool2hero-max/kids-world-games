// placeholder App.jsx
export default function App(){return <div>Kids World Games</div>}